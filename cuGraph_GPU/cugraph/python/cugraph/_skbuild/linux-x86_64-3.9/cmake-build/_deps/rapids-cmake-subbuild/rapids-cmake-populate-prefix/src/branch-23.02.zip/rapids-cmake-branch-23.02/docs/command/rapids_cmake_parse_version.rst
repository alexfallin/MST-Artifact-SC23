.. cmake-module:: ../../rapids-cmake/cmake/parse_version.cmake
