.. cmake-module:: ../../rapids-cmake/cpm/nvcomp.cmake
