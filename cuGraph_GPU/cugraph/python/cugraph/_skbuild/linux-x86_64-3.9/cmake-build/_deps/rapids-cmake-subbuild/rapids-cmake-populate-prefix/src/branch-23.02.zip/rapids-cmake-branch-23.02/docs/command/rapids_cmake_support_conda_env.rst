.. cmake-module:: ../../rapids-cmake/cmake/support_conda_env.cmake
